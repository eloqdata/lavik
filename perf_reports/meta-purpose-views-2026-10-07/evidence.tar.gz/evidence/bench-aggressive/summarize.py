#!/usr/bin/env python3
# Copyright (C) 2026 EloqData Inc.
# SPDX-License-Identifier: Apache-2.0
"""Render medians of the independent trial statistics, not pooled quantiles."""

import argparse
import csv
import json
from pathlib import Path
import statistics


def median(values):
    return statistics.median(float(value) for value in values)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("measurements", type=Path)
    args = parser.parse_args()
    rows = []
    for path in sorted(args.measurements.glob("component-*-*.csv")):
        _, trial, label = path.stem.split("-")
        with path.open() as stream:
            rows.extend(
                dict(row, trial=trial, label=label) for row in csv.DictReader(stream)
            )

    def component(shape, reader, phase, label, field):
        return median(
            row[field]
            for row in rows
            if (row["shape"], row["reader"], row["phase"], row["label"])
            == (shape, reader, phase, label)
        )

    readers = [
        "proposal",
        "facts",
        "create_discovery",
        "membership_discovery",
        "failover_discovery",
        "automatic_detection",
        "publication",
        "admin_group",
        "operation_status",
        "cursor",
    ]
    print("## Unrelated Growth Invariance\n")
    print(
        "All candidate ordinary capture allocation bytes/counts are checked against small at fixed selected records.\n"
    )
    for trial in sorted({row["trial"] for row in rows}):
        for reader in readers:
            selected = {
                row["shape"]: row
                for row in rows
                if row["label"] == "after"
                and row["trial"] == trial
                and row["reader"] == reader
                and row["phase"] == "capture"
            }
            for shape in (
                "unrelated_ops_1",
                "unrelated_ops_16",
                "unrelated_ops_128",
                "archives_1",
                "archives_128",
                "policies_32",
                "manifests_128",
            ):
                for field in ("requested_bytes", "allocations"):
                    if float(selected[shape][field]) != float(selected["small"][field]):
                        raise RuntimeError(
                            f"growth mismatch: {trial} {reader} {shape} {field}"
                        )
    print("PASS: 3 trials x 10 readers x 7 growth fixtures x 2 allocation fields.\n")
    print("## Combined 65536 Component Costs\n")
    print(
        "| Reader | Bytes before/after | Allocations before/after | Capture p50 us before/after | Destroy p50 us before/after | Hold us before/after | Wait us before/after |"
    )
    print("|---|---:|---:|---:|---:|---:|---:|")
    for reader in readers + [
        "audit_export",
        "operation_export",
        "snapshot",
        "command_encode",
    ]:
        cells = []
        for phase, field, scale in [
            ("capture", "requested_bytes", 1),
            ("capture", "allocations", 1),
            ("capture", "p50_ns", 1000),
            ("destroy", "p50_ns", 1000),
            ("capture", "lock_hold_ns", 1000),
            ("capture", "lock_wait_ns", 1000),
        ]:
            cells.append(
                " / ".join(
                    f"{component('combined_65536', reader, phase, label, field) / scale:.3f}"
                    for label in ("before", "after")
                )
            )
        print(f"| {reader} | " + " | ".join(cells) + " |")

    print("\n## Successful Apply With Paced Publication\n")
    print(
        "| Shape | Apply/s before/after | Apply p99 us before/after | Writer lock wait us before/after | Publication p99 us before/after |"
    )
    print("|---|---:|---:|---:|---:|")
    for shape in ("small", "combined_0", "combined_1024", "combined_65536"):
        rates = {}
        for label in ("before", "after"):
            values = []
            for path in args.measurements.glob(f"component-*-{label}.log"):
                for line in path.read_text().splitlines():
                    fields = line.split(",")
                    if fields[:2] == ["apply_per_second", shape]:
                        values.append(fields[2])
            rates[label] = median(values)
        cells = [" / ".join(f"{rates[label]:.1f}" for label in ("before", "after"))]
        for reader, phase, field in [
            ("apply", "contended", "p99_ns"),
            ("apply", "contended", "lock_wait_ns"),
            ("publication", "paced_100hz", "p99_ns"),
        ]:
            cells.append(
                " / ".join(
                    f"{component(shape, reader, phase, label, field) / 1000:.3f}"
                    for label in ("before", "after")
                )
            )
        print(f"| {shape} | " + " | ".join(cells) + " |")

    path = args.measurements / "combined/results.json"
    if not path.exists():
        return
    processes = json.loads(path.read_text())
    print("\n## Concurrent Real Processes\n")
    print(
        "| Audit target | Unrelated operations | Proposal p50/p95/p99 ms before -> after | Publication p99 ms before/after | Admin p99 ms before/after | Sentinel p99 ms before/after | Proposals/s before/after |"
    )
    print("|---:|---:|---|---:|---:|---:|---:|")
    for audit in (0, 1024, 65536):
        for operations in (0, 128):
            selected = {
                label: [
                    row
                    for row in processes
                    if row["audit_target"] == audit
                    and row["operations"] == operations
                    and row["label"] == label
                ]
                for label in ("before", "after")
            }
            if not all(selected.values()):
                continue
            proposal = " -> ".join(
                "/".join(
                    f"{median(row['distributions']['proposal'][quantile] for row in selected[label]) / 1000:.3f}"
                    for quantile in ("p50_us", "p95_us", "p99_us")
                )
                for label in selected
            )
            cells = [proposal]
            for reader in ("publication_from_submit", "admin", "sentinel"):
                cells.append(
                    " / ".join(
                        f"{median(row['distributions'][reader]['p99_us'] for row in selected[label]) / 1000:.3f}"
                        for label in selected
                    )
                )
            cells.append(
                " / ".join(
                    f"{median(row['completed_proposals_per_overlap_second'] for row in selected[label]):.1f}"
                    for label in selected
                )
            )
            print(f"| {audit} | {operations} | " + " | ".join(cells) + " |")
    path = args.measurements / "strict/results.json"
    if path.exists():
        strict = json.loads(path.read_text())
        print("\n## Strict Admission\n")
        for kind in ("near_full_success", "full_rejected"):
            for label in ("before", "after"):
                values = [row for row in strict if row["label"] == label]
                print(
                    kind,
                    label,
                    {
                        quantile: median(row[kind][quantile] for row in values)
                        for quantile in ("p50_us", "p95_us", "p99_us")
                    },
                )


if __name__ == "__main__":
    main()
