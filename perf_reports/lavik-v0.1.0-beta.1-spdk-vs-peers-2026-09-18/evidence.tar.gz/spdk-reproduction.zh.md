## SPDK 配置与复现

先按 [SPDK 存储操作指南](../../docs/operations/spdk-storage.md) 配置。
指南覆盖标准发布包选择、获取匹配版本的设备绑定脚本（无需编译 Lavik）、
序列号与 PCI 地址识别、VFIO/hugepages、启动、配置检查和停止后的驱动恢复。
必须使用包含 SPDK 的标准包，不能用 minimal 包；本次网络仍为 kernel TCP。

本次使用的 6 块专用 NVMe：

| Serial | PCI address | Namespace | Capacity (bytes) |
|---|---|---|---:|
| 40291d45b421bc880001 | `f698:00:00.0` | 1 | 1919850381312 |
| 40291d45b421bc880002 | `d2b4:00:00.0` | 1 | 1919850381312 |
| 40291d45b421bc880003 | `9038:00:00.0` | 1 | 1919850381312 |
| 40291d45b421bc880004 | `3da6:00:00.0` | 1 | 1919850381312 |
| 40291d45b421bc880005 | `674c:00:00.0` | 1 | 1919850381312 |
| 40291d45b421bc880006 | `d408:00:00.0` | 1 | 1919850381312 |

上表地址只属于本次主机，复现时替换为自己核对过的专用控制器；绑定会影响
该控制器的全部 namespace。下面的 `LAVIK_SPDK_SETUP`、`LAVIK_BINARY` 按指南
设为绑定脚本和解压后二进制的路径。启动示例仅替换二进制/日志目录，保留
本次全部性能参数。

本次先保存 hugepages/VFIO 原值，在内核驱动下按序列号核对专用盘并逐盘
`blkdiscard`，再绑定 VFIO。因为测试 VM 没有暴露 IOMMU，本次在绑定前临时
开启 VFIO no-IOMMU；普通 IOMMU 主机不需要这一步，限制和恢复方法见指南。
清盘是全新压测数据集的准备步骤，不是已有数据库的启动或恢复步骤。

```bash
sudo env PCI_ALLOWED='f698:00:00.0 d2b4:00:00.0 9038:00:00.0 3da6:00:00.0 674c:00:00.0 d408:00:00.0' \
  DRIVER_OVERRIDE=vfio-pci HUGEMEM=8192 \
  "$LAVIK_SPDK_SETUP" config
```

1000 万条数据集使用以下启动配置：

```bash
sudo prlimit --memlock=unlimited:unlimited --nofile=65535:65535 \
  env BYCORF_DPDK_MEMORY_MB=8192 \
  BYCORF_EAL_ARGS='-a f698:00:00.0 -a d2b4:00:00.0 -a 9038:00:00.0 -a 3da6:00:00.0 -a 674c:00:00.0 -a d408:00:00.0' \
  taskset -c 0-15 "$LAVIK_BINARY" \
  --network=kernel \
  --storage=spdk \
  --bind=172.16.0.4 \
  --port=6379 \
  --metrics-port=0 \
  --threads=16 \
  --pin-workers \
  --maxclients=10000 \
  --busy-poll-us=20 \
  --foreground-budget-us=1000 \
  --background-budget-us=10 \
  --background-warrant-percent=1 \
  --tomb-raider-interval-ms=0 \
  --spdk-max-completions-per-poll=16 \
  --spdk-foreground-pre-poll-us=5 \
  --log-dir=/var/log/lavik/benchmark \
  --data-file=spdk://f698:00:00.0/1 \
  --data-file=spdk://d2b4:00:00.0/1 \
  --data-file=spdk://9038:00:00.0/1 \
  --data-file=spdk://3da6:00:00.0/1 \
  --data-file=spdk://674c:00:00.0/1 \
  --data-file=spdk://d408:00:00.0/1
```

10 亿条使用相同配置，并增加 `--shutdown-checkpoint`。两个数据集都清盘后
重新灌入，不复用其他后端的 checkpoint。EAL 预留 8 GiB，不是 Lavik 总内存上限。
不传 `--defrag-paused`，每个正式点前确认 `CONFIG GET defrag-paused` 为 `no`；
`CONFIG GET spdk-max-completions-per-poll` 为 `16`。5 µs foreground pre-poll
仅在启动时设置，保留在启动命令及日志中，不通过 `CONFIG GET` 查询。

原始证据中 `memory/lavik-spdk/`、`storage/lavik-spdk/` 分别保存完整启动命令、
EAL 环境变量、盘序列号/PCI 地址、配置检查、绑定/恢复日志和宿主设置前后值。
每个客户端点的 `*.command.json`、memtier JSON 和文本输出也都保留；复现连接数
扫描时替换为自己的服务端地址。采集脚本使用固定序列号白名单，不自动选择任意 NVMe 盘。
