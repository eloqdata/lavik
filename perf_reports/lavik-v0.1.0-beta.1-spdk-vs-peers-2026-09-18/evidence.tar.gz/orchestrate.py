#!/usr/bin/env python3
"""Fresh defrag-enabled Lavik runs; retain separately identified peer controls."""
import json,pathlib,subprocess,time
R=pathlib.Path(__file__).resolve().parent
EXPECTED='3955b98d43b312324aa8d52775df52cfb111c0d0'

def stage(name,command):
    if (R/'STOP').exists():raise RuntimeError('Stop requested')
    if (R/(name+'.complete')).exists():return
    print(time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),'START',name,flush=True)
    with (R/(name+'-progress.log')).open('a') as stream:
        subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,check=True)
    (R/(name+'.complete')).write_text(str(time.time())+'\n')

def main():
    identity=json.loads((R/'binary.json').read_text())
    assert identity['revision']==EXPECTED
    assert identity['version_output']=='lavik 0.1.0-beta.1'
    assert identity['channel']=='tagged-release'
    for keys in [10**7,10**9]:
        stage('spdk-'+str(keys),['python3','-u',str(R/'spdk_fresh.py'),str(keys)])
    (R/'ALL_COMPLETE').write_text(str(time.time())+'\n')
    print('COMPLETE: 22 new defrag-enabled SPDK points plus 124 identified reused controls',flush=True)

if __name__=='__main__':main()
