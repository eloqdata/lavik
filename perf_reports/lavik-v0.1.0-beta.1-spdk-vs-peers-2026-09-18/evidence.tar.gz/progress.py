#!/usr/bin/env python3
import json,pathlib,time
R=pathlib.Path(__file__).resolve().parent
n=sum(1 for p in R.glob('memory/**/*.result.json') if p.name.startswith(('get-','set-')))+sum(1 for p in R.glob('storage/**/*.result.json') if p.name.startswith(('get-','set-')))
print(time.strftime('%H:%M:%S UTC',time.gmtime()),f'{n-124}/22 new SPDK points; 124 reused peer controls')
if (R/'status.json').exists():print(json.loads((R/'status.json').read_text())['message'])
active=R/'active-server.json'
if active.exists():
 a=json.loads(active.read_text());print('server PID',a['pid'],'alive',pathlib.Path('/proc/'+str(a['pid'])).exists())
 message=json.loads((R/'status.json').read_text())['message']
 target=R/(message+'.txt')
 if target.is_file():
  with target.open('rb') as f:
   f.seek(max(0,target.stat().st_size-4096));tail=f.read().decode(errors='replace')
  lines=[line.strip() for line in tail.replace('\r','\n').splitlines() if '[RUN' in line]
  if lines:print(lines[-1])
if (R/'ALL_COMPLETE').exists():print('ALL_COMPLETE')
