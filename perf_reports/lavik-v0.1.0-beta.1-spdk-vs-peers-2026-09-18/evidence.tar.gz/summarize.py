#!/usr/bin/env python3
"""Validate every formal point against its recorded command and client JSON."""
import argparse,csv,hashlib,json,math,pathlib,re
R=pathlib.Path(__file__).resolve().parent
CONNS=[80,160,320,640,1280]
NAMES={'lavik':'Lavik defrag enabled / io_uring','lavik-spdk':'Lavik defrag enabled / SPDK','redis':'Redis 8.8.0','valkey':'Valkey 9.1.0','dragonfly':'Dragonfly v1.40.2','garnet':'Garnet v2.1.5'}

def expectations():
    for system,threads in [('lavik-spdk',16)]+[(s,n) for s in ['redis','valkey'] for n in [1,2,4,8,16]]:
        parent=R/'memory'/system
        if system not in ['lavik','lavik-spdk']:parent/=f'io{threads}'
        for kind in ['GET','SET']:
            for c in CONNS:yield parent/f'{kind.lower()}-c{c}', 'memory',system,threads,kind,c,10**7,30
    for system in ['lavik-spdk','dragonfly','garnet']:
        for kind in ['GET','SET']:
            for c in CONNS+[2560]:yield R/'storage'/system/f'{kind.lower()}-c{c}','storage',system,16,kind,c,10**9,60

def load(partial=False):
    rows=[];missing=[]
    for stem,group,system,threads,kind,c,keys,seconds in expectations():
        result=stem.with_suffix('.result.json')
        if not result.exists():missing.append(str(stem.relative_to(R)));continue
        row=json.loads(result.read_text());args=json.loads(stem.with_suffix('.command.json').read_text())
        if group=='storage' and '--distinct-client-seed' not in args and partial:
            missing.append(str(stem.relative_to(R))+' (superseded correlated streams)');continue
        stats=json.loads(stem.with_suffix('.json').read_text())['ALL STATS']
        required=['--threads=16','--clients='+str(c//16),'--pipeline=1','--key-minimum=1','--key-maximum='+str(keys),'--key-prefix=','--test-time='+str(seconds),'--command-key-pattern=R','--data-size=1024']
        if group=='storage':required+=['--distinct-client-seed']
        assert all(a in args for a in required),(stem,args)
        assert args[:3]==['taskset','-c','0-15'] and not any('rate-limit' in a for a in args)
        assert stats['Totals']['Connection Errors']==0,stem
        assert str(stats['Runtime']['Interrupted']).lower()=='false',stem
        total=stats['Totals'];assert total['Count']>0 and total['Ops/sec']>0,stem
        assert abs(row['qps']-total['Ops/sec'])<.02,stem
        runtime=stats['Runtime'];assert runtime['Time unit']=='MILLISECONDS',stem
        assert runtime['Total duration'] >= seconds*1000-100,stem
        recomputed_qps=total['Count']/(runtime['Total duration']/1000)
        assert abs(recomputed_qps/total['Ops/sec']-1)<0.001,(stem,recomputed_qps,total['Ops/sec'])
        if kind=='GET':assert stats['Gets']['Misses/sec']==0 and abs(stats['Gets']['Hits/sec']-total['Ops/sec'])<.02,stem
        before=json.loads(stem.with_suffix('.before.json').read_text());after=json.loads(stem.with_suffix('.after.json').read_text())
        def ticks(d):
            parts=d['process_stat'].split(') ',1)[1].split()
            return int(parts[11])+int(parts[12])
        # proc snapshots enclose INFO/SSH setup too, so this is diagnostic CPU
        # over the enclosing wall window rather than the exact memtier window.
        cpu=(ticks(after)-ticks(before))/before['clock_ticks']/(after['time']-before['time'])
        system_before=[int(v) for v in before['stat'].splitlines()[0].split()[1:9]]
        system_after=[int(v) for v in after['stat'].splitlines()[0].split()[1:9]]
        system_delta=[a-b for a,b in zip(system_after,system_before)]
        steal=100*system_delta[7]/sum(system_delta) if sum(system_delta)>0 else 0
        role={'lavik':'workers','lavik-spdk':'workers','redis':'io-threads','valkey':'io-threads','dragonfly':'proactors','garnet':'minimum thread-pool threads'}[system]
        r={'group':group,'product':NAMES[system],'system':system,'server_threads':threads,'thread_role':role,'workload':kind,'connections':c,'keys':keys,'value_bytes':1024,'test_seconds':seconds,'client_seed_mode':'distinct' if '--distinct-client-seed' in args else 'default-correlated',
           **{k:row[k] for k in ['qps','avg_ms','p50_ms','p99_ms','p999_ms','p9999_ms']},
           'requests':total['Count'],'client_cores':stats['CPU']['cpu_cores_used'],'server_cores_enclosing_window':round(cpu,4),
           'host_steal_percent_enclosing_window':round(steal,4),
           'connection_errors':total['Connection Errors'],'source':str(stem.relative_to(R))+'.json'}
        rows.append(r)
    if not partial:assert not missing,missing
    return rows,missing

def main():
    p=argparse.ArgumentParser();p.add_argument('--partial',action='store_true');args=p.parse_args()
    rows,missing=load(args.partial)
    if rows:
        with (R/'results.csv').open('w') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
    (R/'validation.json').write_text(json.dumps({'formal_points':len(rows),'expected_points':146,'missing':missing,'all_present_validated_points_have_zero_connection_errors_and_get_misses':True},indent=2)+'\n')
    for group in ['memory','storage']:
        for kind in ['GET','SET']:
            for system in NAMES:
                selection=[r for r in rows if r['group']==group and r['workload']==kind and r['system']==system]
                if selection:
                    best=max(selection,key=lambda r:r['qps']); print(group,kind,system,best['server_threads'],best['connections'],round(best['qps']),best['p999_ms'])
    print('Validated formal points:',len(rows),'/ 146')
if __name__=='__main__':main()
