## SPDK configuration and reproduction

Follow the [SPDK storage guide](../../docs/operations/spdk-storage.md) for
release-package selection, obtaining the pinned setup helper without compiling
Lavik, mapping serial numbers to PCI addresses, VFIO/hugepage preparation,
and restoring kernel drivers after shutdown. The standard package includes
SPDK; the minimal package does not. SPDK storage here uses kernel TCP.

The six benchmark controllers were:

| Serial | PCI address | Namespace | Capacity (bytes) |
|---|---|---|---:|
| 40291d45b421bc880001 | `f698:00:00.0` | 1 | 1919850381312 |
| 40291d45b421bc880002 | `d2b4:00:00.0` | 1 | 1919850381312 |
| 40291d45b421bc880003 | `9038:00:00.0` | 1 | 1919850381312 |
| 40291d45b421bc880004 | `3da6:00:00.0` | 1 | 1919850381312 |
| 40291d45b421bc880005 | `674c:00:00.0` | 1 | 1919850381312 |
| 40291d45b421bc880006 | `d408:00:00.0` | 1 | 1919850381312 |

These addresses and serials belong to this host. Replace them with your own
verified dedicated controllers; binding affects all namespaces on a
controller. `LAVIK_SPDK_SETUP` and `LAVIK_BINARY` below are the helper and
extracted package paths set in the guide. The only path adaptation in the
launch example is the binary/log location; all benchmark options are retained.

The benchmark saved the previous hugepage/VFIO settings, cleared each
serial-allowlisted scratch device with `blkdiscard` while it was owned by the
kernel, and enabled VFIO no-IOMMU mode on this dedicated VM before binding.
The guide explains the VM-specific isolation constraint; ordinary IOMMU
hosts do not need that unsafe mode. Do not erase an existing database to
start or recover it.

```bash
sudo env PCI_ALLOWED='f698:00:00.0 d2b4:00:00.0 9038:00:00.0 3da6:00:00.0 674c:00:00.0 d408:00:00.0' \
  DRIVER_OVERRIDE=vfio-pci HUGEMEM=8192 \
  "$LAVIK_SPDK_SETUP" config
```

Start the 10M-key configuration:

```bash
sudo prlimit --memlock=unlimited:unlimited --nofile=65535:65535 \
  env BYCORF_DPDK_MEMORY_MB=8192 \
  BYCORF_EAL_ARGS='-a f698:00:00.0 -a d2b4:00:00.0 -a 9038:00:00.0 -a 3da6:00:00.0 -a 674c:00:00.0 -a d408:00:00.0' \
  taskset -c 0-15 "$LAVIK_BINARY" \
  --network=kernel \
  --storage=spdk \
  --bind=172.16.0.4 \
  --port=6379 \
  --metrics-port=0 \
  --threads=16 \
  --pin-workers \
  --maxclients=10000 \
  --busy-poll-us=20 \
  --foreground-budget-us=1000 \
  --background-budget-us=10 \
  --background-warrant-percent=1 \
  --tomb-raider-interval-ms=0 \
  --spdk-max-completions-per-poll=16 \
  --spdk-foreground-pre-poll-us=5 \
  --log-dir=/var/log/lavik/benchmark \
  --data-file=spdk://f698:00:00.0/1 \
  --data-file=spdk://d2b4:00:00.0/1 \
  --data-file=spdk://9038:00:00.0/1 \
  --data-file=spdk://3da6:00:00.0/1 \
  --data-file=spdk://674c:00:00.0/1 \
  --data-file=spdk://d408:00:00.0/1
```

For the independent 1B-key load, use the same settings and add
`--shutdown-checkpoint`. Both groups begin with empty media and load data
from scratch. No checkpoint from another backend is reused. The 8 GiB EAL
reservation is separate from Lavik's other memory use. Defrag is enabled
without `--defrag-paused`, and `CONFIG GET defrag-paused` must return `no`.
`CONFIG GET spdk-max-completions-per-poll` returns `16`; the 5 µs foreground
pre-poll is a startup-only option, recorded in the launch command/log.

The archive contains the exact `server-command.json`, `eal-environment.json`,
`devices-before.json`, runtime checks, driver setup/reset logs, and before/after
host settings under `memory/lavik-spdk/` and `storage/lavik-spdk/`.
Client arguments for every point are recorded in `*.command.json` alongside
its memtier JSON and text output. Use those commands with your own host
addresses to reproduce the connection sweep. The scripts never infer that an
arbitrary NVMe drive is disposable.
