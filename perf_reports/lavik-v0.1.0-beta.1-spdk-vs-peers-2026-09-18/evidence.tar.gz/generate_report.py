#!/usr/bin/env python3
"""Render the completed, validated acquisition as repository-native reports."""
import csv,hashlib,json,pathlib,shutil,tarfile,time
import summarize
R=summarize.R
D=pathlib.Path('/mnt/dev/lavik/perf_reports/lavik-v0.1.0-beta.1-spdk-vs-peers-2026-09-18')
LABELS={'lavik-spdk':'Lavik SPDK','redis':'Redis 8.8.0','valkey':'Valkey 9.1.0','dragonfly':'Dragonfly 1.40.2','garnet':'Garnet 2.1.5'}
COLORS={'lavik-spdk':'#1769aa','redis':'#ba6e14','valkey':'#7a8435','dragonfly':'#ba6e14','garnet':'#a6578a'}
LICENSE=pathlib.Path('/mnt/dev/lavik/perf_reports/README.md').read_text().split('-->',1)[0]+'-->\n\n'

def table(headers,rows):
    return '| '+' | '.join(headers)+' |\n| '+' | '.join('---' for _ in headers)+' |\n'+''.join('| '+' | '.join(map(str,row))+' |\n' for row in rows)

def csvfile(path,rows):
    with path.open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)

def best(rows,group,system,kind):
    return max((r for r in rows if r['group']==group and r['system']==system and r['workload']==kind),key=lambda r:r['qps'])

def peak_table(rows,group):
    systems=['lavik-spdk']+(['redis','valkey'] if group=='memory' else ['dragonfly','garnet'])
    result=[]
    for kind in ['GET','SET']:
        for system in systems:
            r=best(rows,group,system,kind)
            result.append([kind,LABELS[system],r['server_threads'],r['connections'],f"{r['qps']:,.0f}",*[f"{r[k]:.3f}" for k in ['avg_ms','p50_ms','p99_ms','p999_ms','p9999_ms']]])
    return table(['Command','System','Threads¹','Connections','QPS','Avg ms','p50 ms','p99 ms','p99.9 ms','p99.99 ms'],result)

def plots(rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#333333','text.color':'#222222','svg.fonttype':'none'})
    for group in ['memory','storage']:
        systems=['lavik-spdk']+(['redis','valkey'] if group=='memory' else ['dragonfly','garnet'])
        for metric,ylabel,filename in [('qps','Throughput (requests/s)',group+'-qps'),('p999_ms','p99.9 latency (ms)',group+'-p999')]:
            fig,axs=plt.subplots(1,2,figsize=(13,5),sharey=True)
            for ax,kind in zip(axs,['GET','SET']):
                for system in systems:
                    selected=best(rows,group,system,kind)['server_threads']
                    series=sorted((r for r in rows if r['group']==group and r['system']==system and r['workload']==kind and r['server_threads']==selected),key=lambda r:r['connections'])
                    label=LABELS[system]+(f' / {selected} I/O threads' if system in ['redis','valkey'] else '')
                    ax.plot([r['connections'] for r in series],[r[metric] for r in series],label=label,color=COLORS[system],linestyle='-',marker={'lavik-spdk':'s','redis':'^','valkey':'D','dragonfly':'^','garnet':'D'}[system],linewidth=2,markersize=5)
                ax.set_xscale('log',base=2);ticks=summarize.CONNS+([2560] if group=='storage' else [])
                ax.set_xticks(ticks,labels=[str(x) for x in ticks]);ax.set_ylim(bottom=0);ax.set_title(kind);ax.set_xlabel('Connections');ax.grid(axis='y',alpha=.2);ax.legend(fontsize=8,loc='best',frameon=False)
                if metric=='qps':ax.yaxis.set_major_formatter(FuncFormatter(lambda x,_:f'{x/1000:g}k'))
            axs[0].set_ylabel(ylabel)
            fig.suptitle(('10M keys / 30 s per point' if group=='memory' else '1B keys / 60 s per point')+' · 1 KiB values · pipeline 1',fontsize=13)
            fig.tight_layout(rect=(0,0,1,.94))
            for ext in ['svg','png']:fig.savefig(D/(filename+'.'+ext),dpi=160,bbox_inches='tight')
            plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(12,4.8),sharey=True)
    for ax,kind in zip(axs,['GET','SET']):
        for system,marker in [('redis','^'),('valkey','D')]:
            xs=[1,2,4,8,16];ys=[max(r['qps'] for r in rows if r['system']==system and r['workload']==kind and r['server_threads']==n) for n in xs]
            ax.plot(xs,ys,color=COLORS[system],marker=marker,label=LABELS[system],linewidth=2)
        ax.set_xscale('log',base=2);ax.set_xticks(xs,labels=[str(x) for x in xs]);ax.set_ylim(bottom=0);ax.set_title(kind);ax.set_xlabel('I/O threads');ax.grid(axis='y',alpha=.2);ax.legend(frameon=False);ax.yaxis.set_major_formatter(FuncFormatter(lambda x,_:f'{x/1000:g}k'))
    axs[0].set_ylabel('Best observed throughput (requests/s)');fig.suptitle('Redis and Valkey thread sweep · 10M keys × 1 KiB');fig.tight_layout(rect=(0,0,1,.94))
    for ext in ['svg','png']:fig.savefig(D/('iothread-scaling.'+ext),dpi=160,bbox_inches='tight')
    plt.close(fig)

def verify_sessions():
    dirs=[R/g/s for g in ['memory','storage'] for s in ['lavik-spdk']]
    dirs += [R/'storage'/s for s in ['dragonfly','garnet']]
    dirs += [R/'memory'/s/f'io{n}' for s in ['redis','valkey'] for n in [1,2,4,8,16]]
    for d in dirs:
        keys=10**9 if d.relative_to(R).parts[0]=='storage' else 10**7
        for phase in ['before','after']:
            if d.name=='garnet' and phase=='after' and not (d/'validation-after.json').exists():
                waiver=json.loads((d/'validation-after-waived.json').read_text())
                assert waiver['validation_before_passed'] and waiver['validation_after_completed'] is False
                assert waiver['user_instruction']=='不用校验吧，又不影响实验结果'
                continue
            v=json.loads((d/f'validation-{phase}.json').read_text());assert v['dbsize']==str(keys) and set(v['lengths'].values())=={'1024'},d
        code=int((d/'exit-code.txt').read_text());assert code==0 or (d.name=='garnet' and code==-15),(d,code)
        if d.name=='lavik-spdk':
            assert json.loads((d/'host-state-before.json').read_text())==json.loads((d/'host-state-after.json').read_text()),d
        fill=d/'fill.json'
        if fill.exists():assert json.loads(fill.read_text())['ALL STATS']['Totals']['Count']==keys,d
    return len(dirs)

def main():
    assert (R/'ALL_COMPLETE').exists(), 'Acquisition incomplete'
    rows, missing = summarize.load()
    assert len(rows)==146 and not missing
    sessions=verify_sessions()
    binary=json.loads((R/'binary.json').read_text());revision=binary['revision']
    assert binary['channel']=='tagged-release' and binary['version_output']=='lavik 0.1.0-beta.1'
    assert json.loads((R/'tag.json').read_text())['annotated_tag']['object']['sha']==revision
    for group in ['memory','storage']:
        p=R/group/'lavik-spdk'
        assert json.loads((p/'defrag-runtime-config.json').read_text())['defrag-paused'].splitlines()==['defrag-paused','no']
        assert '--defrag-paused' not in json.loads((p/'server-command.json').read_text())
        for snapshot in [*p.glob('get-*.before.json'),*p.glob('set-*.before.json')]:
            assert 'defrag_paused:0' in json.loads(snapshot.read_text())['info']
    D.mkdir(parents=True,exist_ok=True)
    csvfile(D/'results.csv',rows)
    for g in ['memory','storage']:csvfile(D/(g+'-results.csv'),[r for r in rows if r['group']==g])
    for name in ['binary.json','release.json','tag.json','control-provenance.json']:
        shutil.copyfile(R/name,D/name)
    shutil.copyfile(R/'host/binaries.json',D/'binaries.json')
    plots(rows)
    summary=[];zh_summary=[]
    for group,title,zh_title in [('memory','10M','1000 万条'),('storage','1B','10 亿条')]:
        for kind in ['GET','SET']:
            r=best(rows,group,'lavik-spdk',kind)
            summary.append(f"- {title} {kind}: SPDK peak **{r['qps']/1000:.1f}k QPS** at {r['connections']} connections; p99 **{r['p99_ms']:.3f} ms**, p99.9 **{r['p999_ms']:.3f} ms** at that point.")
            zh_summary.append(f"- {zh_title} {kind}：SPDK 峰值 **{r['qps']/1000:.1f}k QPS**（{r['connections']} 连接），该点 p99 **{r['p99_ms']:.3f} ms**、p99.9 **{r['p999_ms']:.3f} ms**。")
    thread_rows=[]
    for system in ['redis','valkey']:
        for n in [1,2,4,8,16]:
            picks=[max((r for r in rows if r['system']==system and r['server_threads']==n and r['workload']==k),key=lambda r:r['qps']) for k in ['GET','SET']]
            thread_rows.append([LABELS[system],n,*[f"{r['qps']:,.0f} @ {r['connections']}" for r in picks]])
    common=f'''## Method and scope

- Downloaded the standard x86_64 [v0.1.0-beta.1 release](https://github.com/eloqdata/lavik/releases/tag/v0.1.0-beta.1) at `{binary['downloaded_at_utc']}`. Asset: `{binary['asset']}`. The archive checksum matches its published SHA-256 file. Source revision: `{revision}`; executable SHA-256: `{binary['sha256']}`. The executable reports `{binary['version_output']}`. The annotated tag resolves to the archive revision (tag.json). No Lavik rebuild or source patch. The interrupted nightly attempt is retained under `aborted-nightly-attempt/` for provenance and contributes no reported measurements.
- Server: 172.16.0.4, AMD EPYC 9V74, 8 physical cores / 16 logical CPUs, approximately 126 GiB RAM. Client: 172.16.0.5, AMD EPYC 9V45, 16 cores, approximately 31 GiB RAM. All products and the client are pinned to CPUs 0–15. One product runs at a time; CPU/IRQ placement is not tuned during the experiment.
- Lavik uses 16 workers, kernel TCP, six serial-verified raw NVMe disks, busy-poll 20 µs, foreground/background budgets 1000/10 µs, background warrant 1%, defrag enabled (`defrag-paused=no`, verified before every formal point) and Tomb Raider disabled. The metrics listener is disabled; enclosing-window OS/INFO snapshots are collected. SPDK starts with cleared disks and independently loads both dataset sizes. No io_uring dataset or checkpoint is reused. The user excluded io_uring from the final scope; its interrupted acquisition remains under excluded-io-uring-attempt/ and contributes no reported measurements.
- SPDK uses VFIO, eight GiB of hugepages, completion cap 16 and foreground pre-poll 5 µs. The VM requires VFIO no-IOMMU mode. Only the six benchmark controllers are rebound. Their kernel driver ownership, hugepage count and VFIO mode are restored after each session. OS and workspace disks are excluded.
- Redis 8.8.0 and Valkey 9.1.0 test 1/2/4/8/16 I/O threads with AOF and automatic snapshots disabled. Each configuration starts from its product's freshly generated, hash-verified 10M-key RDB, verifies the configured thread count and receives a 10-second GET warmup.
- Dragonfly 1.40.2 uses 16 proactors, 96 GiB maxmemory and Tiered Storage. Garnet 2.1.5 uses a 64 GiB hybrid log, 32 GiB read cache, 16 GiB index and Libaio Storage Tier. Both use files on RAID0/XFS built from the same six benchmark NVMe disks, then receive a 180-second GET warmup (eight client threads, 80 connections). The benchmark RAID is unmounted and stopped before SPDK.
- Garnet's pre-test exact DBSIZE scan passed with future compaction paused, log boundaries stable for 30 seconds, and unchanged boundaries across the scan. Lookup compaction was restored and verified before every formal point. The post-test full scan was stopped at the user's request after all 12 formal points had completed; the post-test key count and value-length check are therefore unverified. The waiver, interrupted-client traceback and actual SIGTERM server exit status are retained in the evidence. Pausing compaction avoids counting moved records twice during a concurrent scan; the pre-test scan itself affects cache and storage history.
- All formal clients use memtier 2.5.1, 16 threads, pipeline=1, no rate limit, decimal keys 1..N without prefixes, 1,024-byte values, uniform random GET or overwriting SET. 10M points run for 30 seconds at 80/160/320/640/1280 connections; 1B points run for 60 seconds and add 2560 connections. Lavik receives a 10-second GET warmup for 10M and no additional 1B warmup, matching the prior acquisition.
- The 10M group retains the historical scripts' default correlated client seeds. The 1B group uses `--distinct-client-seed` for every product to avoid artificial locality from cloned random streams. The September 6 storage acquisition's seed behavior could not be established from the report; this is a disclosed methodological difference, not a code-only performance comparison.
- Each formal point is one run. Dataset counts and sampled value lengths are validated before every configuration and after every configuration except Garnet, whose post-test scan was waived by the user. All measured GETs have zero misses, and all 146 formal points have zero connection errors. These client checks do not substitute for Garnet's omitted post-test exact count. QPS and client latency describe the memtier measurement window; server CPU snapshots enclose additional setup and INFO work.
- The 124 peer-control points are reused from the earlier September 18 sweep and are compared with SPDK; only the 22 Lavik SPDK points are newly measured in this defrag-enabled run. Source paths, timestamps and control-provenance.json identify the reused data. The earlier Lavik baseline used revision 97f63d0 with defrag paused, whereas this run uses 3955b98 with defrag enabled; any between-run change includes both differences. Products run sequentially, not interleaved; temporal variation, CPU baseline, memory reservations, disk topology, cache policies and persistence guarantees limit causal interpretations. The old report used a Clang/native Lavik build; this report uses the downloaded GCC/x86-64-v2 package. Do not compare absolute rankings across the 10M and 1B groups or claim equal crash durability. Small differences do not establish statistical significance.

¹ Thread roles differ: Lavik workers, Redis/Valkey I/O threads, Dragonfly proactors, and Garnet minimum thread-pool threads. Garnet's actual thread count is not fixed at 16, but all threads share the 16-CPU affinity limit.

## Evidence and reproduction

[All 146 points](results.csv) · [10M results](memory-results.csv) · [1B results](storage-results.csv) · [Binary identity](binary.json) · [Peer hashes](binaries.json) · [Release metadata](release.json) · [Raw manifest](raw-SHA256SUMS) · [Raw evidence](evidence.tar.gz)

Raw acquisition root: `{R}`. `runner.py` provides the shared acquisition routines, `spdk_fresh.py` acquires fresh SPDK data, `orchestrate.py` serializes the stages, and `summarize.py` validates every formal point against its recorded command and client JSON. These are host-specific scripts with an explicit six-device allowlist and destructive scratch-storage preparation. `generate_report.py` requires the complete validated matrix before rendering. The evidence archive excludes executable downloads and generated datasets; each raw file has a recorded SHA-256.
'''
    english = "# Lavik v0.1.0-beta.1: SPDK with defrag enabled versus peers\n\n**English** | [简体中文](README.zh-CN.md)\n\nSeptember 18, 2026. Measured the downloaded standard beta release package on fresh SPDK datasets. This report contains 22 new Lavik points and 124 reused peer-control points from the earlier September 18 sweep on the same hosts. io_uring is excluded from this report.\n\n" + '\n'.join(summary)
    english += '\n\n## 10M keys × 1 KiB: in-memory controls\n\n![10M throughput](memory-qps.png)\n\n' + peak_table(rows,'memory') + '\n![10M p99.9](memory-p999.png)\n\nRedis and Valkey curves select the best measured thread count separately for GET and SET; the latency chart uses those same configurations.\n'
    english += '\n## 1B keys × 1 KiB: storage-tier controls\n\n![1B throughput](storage-qps.png)\n\n' + peak_table(rows,'storage') + '\n![1B p99.9](storage-p999.png)\n'
    english += '\n## Redis and Valkey I/O-thread sweep\n\n![I/O threads](iothread-scaling.png)\n\n' + table(['System','I/O threads','Peak GET QPS @ connections','Peak SET QPS @ connections'],thread_rows)
    english += '\n' + (R/'spdk-reproduction.en.md').read_text() + '\n' + common
    (D/'README.md').write_text(LICENSE+english)
    zh = "# Lavik v0.1.0-beta.1：开启 defrag 的 SPDK 与竞品对比\n\n[English](README.md) | **简体中文**\n\n2026 年 9 月 18 日。使用实际下载的标准 beta 发布包，在独立清盘重灌的数据集上测量 SPDK；报告包含新测的 22 个 Lavik 点，以及当天早些时候在相同主机上完成的 124 个竞品对照点。本报告不纳入 io_uring。\n\n" + '\n'.join(zh_summary)
    zh += '\n\n## 1000 万条：Redis / Valkey 内存组\n\n![吞吐量](memory-qps.png)\n\n' + peak_table(rows,'memory') + '\n![p99.9 延迟](memory-p999.png)\n\nRedis、Valkey 分别按 GET / SET 的实测峰值选择 I/O 线程数，延迟图使用相同配置。\n'
    zh += '\n## 10 亿条：Dragonfly / Garnet 存储层组\n\n![吞吐量](storage-qps.png)\n\n' + peak_table(rows,'storage') + '\n![p99.9 延迟](storage-p999.png)\n'
    zh += '\n## Redis / Valkey I/O 线程扫描\n\n![线程扫描](iothread-scaling.png)\n\n' + table(['产品','I/O 线程','GET 峰值 QPS @ 连接数','SET 峰值 QPS @ 连接数'],thread_rows)
    zh += '\n' + (R/'spdk-reproduction.zh.md').read_text() + '\n' + (R/'method.zh.md').read_text().format(revision=revision,sha256=binary['sha256'])
    (D/'README.zh-CN.md').write_text(LICENSE+zh)
    evidence=[]
    for p in sorted(R.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(R)
        if any(part in ['downloads','data','__pycache__'] for part in rel.parts):continue
        if p.suffix=='.rdb' or p.name=='evidence.tar.gz':continue
        evidence.append(p)
    manifest=''.join(hashlib.file_digest(p.open('rb'),'sha256').hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in evidence)
    (D/'raw-SHA256SUMS').write_text(manifest)
    with tarfile.open(D/'evidence.tar.gz','w:gz') as archive:
        for p in evidence:archive.add(p,arcname=p.relative_to(R).as_posix())
    (D/'evidence.tar.gz.sha256').write_text(hashlib.file_digest((D/'evidence.tar.gz').open('rb'),'sha256').hexdigest()+'  evidence.tar.gz\n')
    (D/'validation.json').write_text(json.dumps({'formal_points':len(rows),'new_lavik_points':22,'reused_peer_points':124,'backend':'SPDK','defrag_paused':False,'checked_sessions':sessions,'fully_verified_sessions':sessions-1,'post_validation_waivers':['storage/garnet/validation-after-waived.json'],'zero_connection_errors':True,'zero_get_misses':True,'source_revision':revision},indent=2)+'\n')
    print(D)
if __name__=='__main__':main()
