#!/usr/bin/env python3
"""Update the existing benchmark excerpts from completed release measurements."""
import pathlib
import generate_report as report

root = pathlib.Path('/mnt/dev/lavik')
rows, missing = report.summarize.load()
assert not missing and (report.R/'ALL_COMPLETE').exists()

def peak(group, system, kind):
    return report.best(rows, group, system, kind)

mg = peak('memory', 'lavik-spdk', 'GET')
ms = peak('memory', 'lavik-spdk', 'SET')
sg = peak('storage', 'lavik-spdk', 'GET')
ss = peak('storage', 'lavik-spdk', 'SET')
rg = peak('memory', 'redis', 'GET')
vg = peak('memory', 'valkey', 'GET')
dg = peak('storage', 'dragonfly', 'GET')
gg = peak('storage', 'garnet', 'GET')
ds = peak('storage', 'dragonfly', 'SET')
gs = peak('storage', 'garnet', 'SET')
dest = report.D.relative_to(root).as_posix()
p = root/'README.md'
s = p.read_text()

def replace_between(start, end, replacement):
    global s
    a = s.index(start)
    b = s.index(end, a)
    s = s[:a] + replacement + '\n\n' + s[b:]

replace_between('- **Multiples of the throughput', '- **Put multiple CPU cores', f'''- **Multiples of the throughput of disk-backed alternatives.** In the
  **one-billion-key, 1 TB** test, Lavik v0.1.0-beta.1 with SPDK and defrag
  enabled reached **{sg['qps']:,.0f} GET QPS**:
  **{sg['qps']/dg['qps']:.2f}× Dragonfly's and {sg['qps']/gg['qps']:.2f}× Garnet's peak read throughput**.
  In the broader 200-million-key comparison, Lavik SPDK delivered
  **2.44–4.93× the throughput of Pika, Apache Kvrocks, and Tendis** across
  the tested read, write, and mixed workloads.
  See [disk-backed comparisons](#disk-backed-kv-systems).

- **NVMe storage, near in-memory performance.** On an AMD EPYC 9V74 server
  with approximately 126 GiB RAM and six raw NVMe drives, Lavik v0.1.0-beta.1
  with SPDK and defrag enabled reached **{mg['qps']:,.0f} GET QPS** and
  **{ms['qps']:,.0f} SET QPS** over **10 million keys with 1 KiB values**.
  GET/SET p99 latency at those peaks was **{mg['p99_ms']:.3f} / {ms['p99_ms']:.3f} ms**.
  See [in-memory comparisons](#in-memory-redis-and-valkey) for Redis/Valkey
  controls and measurement limits.''')

replace_between('**Lavik delivers multi-fold throughput', 'Browse the [performance reports]', '''**Lavik delivers multi-fold throughput gains over several disk-backed KV
systems.** The September 18 comparison measures the downloaded v0.1.0-beta.1
release with defrag enabled, using SPDK. It includes
throughput and tail latency against Redis, Valkey, Dragonfly, and Garnet.''')

replace_between('The September 18 [1 TB storage-tier test]', 'In the August 12 dual-NVMe test', f'''The September 18 [1 TB storage-tier test]({dest}/README.md#1b-keys--1-kib-storage-tier-controls)
used **one billion 1 KiB values** on an AMD EPYC 9V74 server with six NVMe
drives. The downloaded Lavik v0.1.0-beta.1 with SPDK and defrag enabled peaked
at **{sg['qps']:,.0f} GET QPS**, or **{sg['qps']/dg['qps']:.2f}× Dragonfly's and {sg['qps']/gg['qps']:.2f}× Garnet's peak read throughput**.
Its **{ss['qps']:,.0f} SET QPS** was **{ss['qps']/ds['qps']:.2f}× Dragonfly's and {ss['qps']/gs['qps']:.2f}× Garnet's**.
These compare each system's highest measured point within its concurrency
sweep and are separate from the dual-NVMe table above. Lavik SPDK
used freshly loaded datasets; the controls reuse the earlier September 18
measurements on the same hosts. Garnet's post-measurement full key-count scan
was omitted after its formal tests completed, as documented in the report.''')

table = ['| System | Peak GET QPS | GET p99 | Peak SET QPS | SET p99 |',
         '|---|---:|---:|---:|---:|']
for system, label in [('lavik-spdk','Lavik SPDK'),('redis','Redis 8.8.0'),('valkey','Valkey 9.1.0')]:
    g = peak('memory', system, 'GET')
    t = peak('memory', system, 'SET')
    table.append(f"| {label} | {g['qps']:,.0f} | {g['p99_ms']:.3f} ms | {t['qps']:,.0f} | {t['p99_ms']:.3f} ms |")
replace_between('The September 18 [Redis/Valkey comparison]', '## Important notes', f'''The September 18 [Redis/Valkey comparison]({dest}/README.md#10m-keys--1-kib-in-memory-controls)
used an AMD EPYC 9V74 server with approximately 126 GiB RAM and
**10 million keys with 1 KiB values** (about 10 GB). The downloaded Lavik
v0.1.0-beta.1 tested SPDK with defrag enabled, using six raw NVMe
devices and separately loaded datasets. Redis 8.8.0 and Valkey 9.1.0 held
the complete dataset in memory. Tests swept 80–1,280 connections with
pipeline=1 and 30-second measurement windows, selecting each in-memory
system's best measured I/O-thread setting per command.

![Lavik SPDK versus tuned in-memory Redis and Valkey]({dest}/memory-qps.svg)

{chr(10).join(table)}

Lavik SPDK's GET peak occurred at {mg['connections']:,} connections and its SET
peak at {ms['connections']:,}. Each point has one run, so small differences do
not establish statistical significance. Redis and Valkey had AOF and
automatic RDB saves disabled. Their controls reuse the earlier September 18
sweep; all Lavik points were measured again with the beta release package
and defrag enabled. This 10 GB test is independent of the larger
storage-tier benchmark above.''')
p.write_text(s)
p = root/'perf_reports/README.md'
s = p.read_text().replace('| Downloaded nightly: raw io_uring', '| Earlier nightly, defrag paused: raw io_uring')
line = f'| v0.1.0-beta.1 release, defrag enabled: fresh SPDK versus peers | 2026-09-18 | [English]({report.D.name}/README.md) | [简体中文]({report.D.name}/README.zh-CN.md) |\n'
if line not in s:
    s = s.replace('| Earlier nightly, defrag paused:', line+'| Earlier nightly, defrag paused:')
p.write_text(s)
print('Updated README benchmark excerpts and performance-report index')
