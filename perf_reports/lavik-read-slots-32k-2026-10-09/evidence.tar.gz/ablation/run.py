#!/usr/bin/env python3
"""Compare only the registered read slot size on one native SPDK image."""
import pathlib,sys,json,os,resource,hashlib,time,shutil
R=pathlib.Path(__file__).resolve().parent
OLD=pathlib.Path('/mnt/dev/peer-bench/main-spdk-followup-2026-10-09')
sys.path.insert(0,str(OLD));import bench,host_setup
b=bench.b;b.R=R;b.REMOTE='/mnt/dev/read-slots-32k-20261009';host_setup.R=R
BINARY=R.parent/'lavik-32k'

def session(name,kib):
 d=R/name;assert not d.exists()
 args=json.loads((OLD/'20-main-spdk-1b/server-command.json').read_text())[3:]
 binary=BINARY
 args[0]=str(binary)
 args=[a for a in args if not a.startswith('--log-dir=') and a!='--defrag-paused']
 args+=['--log-dir='+str(d/'logs')]
 # Compare the complete candidate (including SPDK backpressure) with the
 # original runtime and 1 MiB slots, keeping all build/runtime flags fixed.
 if kib!=32:args+=['--storage-read-buffer-kb='+str(kib)]
 devs=json.loads((R/'host-before.json').read_text())['devices']
 assert all(pathlib.Path('/sys/bus/pci/devices',x['bdf'],'driver').resolve().name=='vfio-pci' for x in devs)
 env=dict(os.environ,BYCORF_DPDK_MEMORY_MB='8192',BYCORF_EAL_ARGS=' '.join('-a '+x['bdf'] for x in devs))
 resource.setrlimit(resource.RLIMIT_MEMLOCK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
 b.write(d/'environment.json',{k:env[k] for k in ['BYCORF_DPDK_MEMORY_MB','BYCORF_EAL_ARGS']})
 with b.server(args,d,env=env) as pid:
  assert b.cli('CONFIG','GET','defrag-paused').splitlines()[-1]=='no'
  b.write(d/'validation-before.json',b.validate(10**9))
  log=(d/'logs/lavik.log').read_text()
  assert f'storage_read_buffer_bytes={kib*1024} ' in log
  b.memtier(d,'warmup',10**9,'GET',640,10,pid)
  for n in range(3):b.memtier(d,'set-c640-r'+str(n+1),10**9,'SET',640,60,pid)
  b.write(d/'validation-after.json',b.validate(10**9))
 b.write(d/'complete.json',{'read_payload_kib':kib,'sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'time':time.time()})

def main():
 assert not (R/'BENCHMARKS_COMPLETE').exists()
 assert (R.parent/'correctness-complete.json').exists()
 host_setup.capture()
 try:
  host_setup.change('bind')
  for n,kib in enumerate([1024],1):
   if (R/'STOP').exists():raise RuntimeError('Stop requested')
   session(f'{n:02d}-read-{kib}k',kib)
  (R/'BENCHMARKS_COMPLETE').touch()
 finally:host_setup.change('restore')
if __name__=='__main__':main()
