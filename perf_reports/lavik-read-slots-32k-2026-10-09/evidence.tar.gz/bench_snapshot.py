#!/usr/bin/env python3
import pathlib,sys,json,os,subprocess,shlex,re,time,hashlib,resource
PREV=pathlib.Path('/mnt/dev/peer-bench/main-resp-buffer-2026-10-08')
sys.path.insert(0,str(PREV))
import run
b=run.b;R=pathlib.Path(__file__).resolve().parent
b.R=R;b.REMOTE='/mnt/dev/main-spdk-followup-20261009'
def session(name,variant,backend,keys=10**9,full=False,fill=False):
 d=R/name;assert not d.exists(),d
 binary=R/({"main":"main-fixed-lavik","final":"buffer-fixed-lavik"}[variant])
 expected=json.loads((R/'build-manifest.json').read_text())['sha256'][binary.name]
 assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==expected
 env=dict(os.environ)
 if backend=='spdk':
  devices=json.loads((R/'host-before.json').read_text())['devices']
  bdfs=[x['bdf'] for x in devices]
  assert all(pathlib.Path('/sys/bus/pci/devices',x,'driver').resolve().name=='vfio-pci' for x in bdfs)
  paths=['spdk://'+x+'/1' for x in bdfs]
  env.update(BYCORF_DPDK_MEMORY_MB='8192',BYCORF_EAL_ARGS=' '.join('-a '+x for x in bdfs))
  resource.setrlimit(resource.RLIMIT_MEMLOCK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
 else:paths=b.DEVICES
 args=[binary,'--network=kernel','--storage='+backend,'--bind='+b.S,'--port=6379','--metrics-port=19100','--threads=16','--pin-workers','--maxclients=10000','--busy-poll-us=20','--foreground-budget-us=1000','--background-budget-us=10','--background-warrant-percent=1','--registered-buffer-mb-per-worker=256','--flush-max-ms=1000','--spdk-max-completions-per-poll=16','--spdk-foreground-pre-poll-us=5','--defrag-paused','--tomb-raider-interval-ms=0','--shutdown-checkpoint','--log-dir='+str(d/'logs')]+['--data-file='+x for x in paths]
 b.write(d/'environment.json',{x:env.get(x) for x in ['BYCORF_DPDK_MEMORY_MB','BYCORF_EAL_ARGS']})
 with b.server(args,d,env=env) as pid:
  if fill:
   assert b.cli('DBSIZE')=='0', 'Fresh population requires empty media'
   b.memtier(d,'fill',keys,'fill',pid=pid)
  b.write(d/'validation-before.json',b.validate(keys))
  if backend=='spdk':assert b.cli('CONFIG','GET','spdk-max-completions-per-poll').splitlines()[-1]=='16'
  if keys==10**7:b.memtier(d,'warmup',keys,'GET',seconds=10,pid=pid)
  if full:
   counts=[80,160,320,640,1280]+([2560] if keys==10**9 else [])
   for c in counts:b.memtier(d,f'get-c{c}',keys,'GET',c,60 if keys==10**9 else 30,pid)
   for c in counts:b.memtier(d,f'set-c{c}',keys,'SET',c,60 if keys==10**9 else 30,pid)
  else:
   for kind in (['GET'] if keys==10**9 else ['GET','SET']):
    for c in [640,1280]:b.memtier(d,f'{kind.lower()}-c{c}',keys,kind,c,60 if keys==10**9 else 30,pid)
  b.write(d/'validation-after.json',b.validate(keys))
 b.write(d/'complete.json',{'time':time.time(),'sha256':expected})

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('variant',choices=['main','final']);p.add_argument('backend',choices=['uring','spdk']);p.add_argument('--keys',type=int,default=10**9);p.add_argument('--full',action='store_true');p.add_argument('--fill',action='store_true');a=p.parse_args();session(a.name,a.variant,a.backend,a.keys,a.full,a.fill)
