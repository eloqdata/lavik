import pathlib,sys,subprocess,socket,time,signal,json,importlib.util
R=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('protocol','/mnt/dev/peer-bench/main-spdk-followup-2026-10-09/correctness.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sizes=[1,4095,8191,8192,8193,16383,16384,16385,24575,24576,32767,32768,32769,65536,131072,1048576,2097152]
def value(n):return (b'a\x00b\r\ncdef'*(n//9+1))[:n]
values={f'size:{n}'.encode():value(n) for n in sizes}
for n in [2048,2049,32769]:values[b'k'*n]=value(65536)
data=R/'correctness.data';assert not data.exists()
with data.open('wb') as f:f.truncate(1024**3)
for phase in ['write','read']:
 args=[str(R/'build/lavik'),'--bind=127.0.0.1','--port=16389','--threads=2','--data-file='+str(data),'--storage=uring','--registered-buffer-mb-per-worker=256','--flush-max-ms=20','--shutdown-checkpoint','--log-dir='+str(R/('correctness-'+phase+'-logs'))]
 with (R/('correctness-'+phase+'.log')).open('w') as out:
  p=subprocess.Popen(args,stdout=out,stderr=subprocess.STDOUT)
  try:
   deadline=time.monotonic()+60
   while True:
    assert p.poll() is None,'server exited'
    try:c=m.Client();break
    except OSError:
     assert time.monotonic()<deadline,'startup timeout';time.sleep(.1)
   if phase=='write':
    for k,v in values.items():assert c.cmd('SET',k,v)==b'OK'
    assert c.cmd('HSET','large-hash','field',value(262144))==1
    assert c.cmd('RPUSH','large-list',value(131072))==1
    assert c.cmd('SADD','large-set',value(131072))==1
    assert c.cmd('ZADD','large-zset','1',value(131072))==1
   for k,v in values.items():assert c.cmd('GET',k)==v,(phase,len(k),len(v))
   assert c.cmd('HGET','large-hash','field')==value(262144)
   assert c.cmd('LINDEX','large-list','0')==value(131072)
   assert c.cmd('SISMEMBER','large-set',value(131072))==1
   assert c.cmd('ZSCORE','large-zset',value(131072))==b'1'
   assert c.cmd('DBSIZE')==len(values)+4
   c.close()
  finally:
   if p.poll() is None:p.send_signal(signal.SIGTERM)
   p.wait(timeout=60);assert p.returncode==0,p.returncode
 log=(R/('correctness-'+phase+'-logs')/'lavik.log').read_text();assert 'storage_read_buffer_bytes=32768 ' in log
(R/'correctness-complete.json').write_text(json.dumps({'passed':True,'string_sizes':sizes,'long_key_sizes':[2048,2049,32769],'large_collection_values':[131072,262144],'phases':['staged/read','disk read after restart'],'registered_pool_mib':256,'read_payload_kib':32,'time':time.time()},indent=2)+'\n')
print('32 KiB slot boundary, long-key, large collection and post-restart disk reads passed')
