import pathlib,sys,json,os,resource,socket,time,importlib.util
R=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,'/mnt/dev/peer-bench/main-spdk-followup-2026-10-09')
import bench,host_setup
b=bench.b; b.R=R;host_setup.R=R
spec=importlib.util.spec_from_file_location('protocol','/mnt/dev/peer-bench/main-spdk-followup-2026-10-09/correctness.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Client(m.Client):
 def __init__(self):
  self.s=socket.create_connection((b.S,b.PORT));self.s.settimeout(30);self.f=self.s.makefile('rb')
sizes=[1,4095,8191,8192,8193,16383,16384,16385,24575,24576,32767,32768,32769,65536,131072,1048576,2097152]
def value(n):return (b'a\x00b\r\ncdef'*(n//9+1))[:n]
values={f'size:{n}'.encode():value(n) for n in sizes}
for n in [2048,2049,32769]:values[b'k'*n]=value(65536)

def exercise(phase):
 c=Client();assert c.cmd('SELECT',15)==b'OK'
 if phase=='write':assert c.cmd('DBSIZE')==0,'Test database must be empty'
 if phase=='write':
  for k,v in values.items():assert c.cmd('SET',k,v)==b'OK'
  assert c.cmd('HSET','large-hash','field',value(262144))==1
  assert c.cmd('RPUSH','large-list',value(131072))==1
  assert c.cmd('SADD','large-set',value(131072))==1
  assert c.cmd('ZADD','large-zset','1',value(131072))==1
 for k,v in values.items():assert c.cmd('GET',k)==v,(phase,len(k),len(v))
 assert c.cmd('HGET','large-hash','field')==value(262144)
 assert c.cmd('LINDEX','large-list','0')==value(131072)
 assert c.cmd('SISMEMBER','large-set',value(131072))==1
 assert c.cmd('ZSCORE','large-zset',value(131072))==b'1'
 assert c.cmd('DBSIZE')==len(values)+4

 if phase=='read':
  for k in values:assert c.cmd('DEL',k)==1
  for k in ['large-hash','large-list','large-set','large-zset']:assert c.cmd('DEL',k)==1
  assert c.cmd('DBSIZE')==0
 c.close()

def main():
 host_setup.capture()
 try:
  host_setup.change('bind')
  resource.setrlimit(resource.RLIMIT_MEMLOCK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
  devs=json.loads((R/'host-before.json').read_text())['devices']
  env=dict(os.environ,BYCORF_DPDK_MEMORY_MB='8192',BYCORF_EAL_ARGS=' '.join('-a '+x['bdf'] for x in devs))
  # Match the old read concurrency approximately while retaining 32 KiB
  # slots: 41 MiB - four 8 MiB writes leaves room for 230 read slots.
  d=R/'budget41'
  args=json.loads((R.parent/'06-read-32k/server-command.json').read_text())[3:]
  args=[a for a in args if not a.startswith(('--log-dir=','--registered-buffer-mb-per-worker='))]+['--registered-buffer-mb-per-worker=41','--log-dir='+str(d/'logs')]
  with b.server(args,d,env=env) as pid:
   b.validate(10**9)
   b.memtier(d,'warmup',10**9,'GET',640,10,pid)
   for n in range(3):b.memtier(d,'set-c640-r'+str(n+1),10**9,'SET',640,60,pid)
   b.validate(10**9)
  for phase in ['write','read']:
   d=R/phase
   args=json.loads((R.parent/'06-read-32k/server-command.json').read_text())[3:]
   args=[a for a in args if not a.startswith('--log-dir=')]+['--log-dir='+str(d/'logs')]
   with b.server(args,d,env=env) as pid:
    b.validate(10**9); exercise(phase); b.validate(10**9)
   assert (d/'exit-code.txt').read_text().strip()=='0'
  (R/'complete.json').write_text(json.dumps({'passed':True,'db':15,'cleaned':True,'string_sizes':sizes,'large_collection_values':[131072,262144],'long_key_sizes':[2048,2049,32769],'time':time.time()},indent=2)+'\n')
 finally:host_setup.change('restore')
if __name__=='__main__':main()
