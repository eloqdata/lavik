import pathlib,time,subprocess
R=pathlib.Path(__file__).resolve().parent
deadline=time.monotonic()+1200
while not ((R/'BENCHMARKS_COMPLETE').exists() and (R/'host-restored.json').exists()):
 assert not (R/'STOP').exists(),'Stop requested'
 assert time.monotonic()<deadline,'Formal benchmark did not complete'
 time.sleep(1)
for name in ['ablation','spdk-boundaries']:
 assert not (R/'STOP').exists(),'Stop requested'
 with (R/name/'progress.log').open('w') as f:
  subprocess.run(['python3','-u',str(R/name/'run.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
(R/'ALL_CHECKS_COMPLETE').touch()
