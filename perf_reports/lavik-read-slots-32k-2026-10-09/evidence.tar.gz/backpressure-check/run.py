import pathlib,sys,json,os,subprocess,resource
R=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,'/mnt/dev/peer-bench/main-spdk-followup-2026-10-09')
import host_setup
host_setup.R=R
host_setup.capture()
try:
 host_setup.change('bind')
 resource.setrlimit(resource.RLIMIT_MEMLOCK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
 devs=json.loads((R/'host-before.json').read_text())['devices']
 env=dict(os.environ,BYCORF_DPDK_MEMORY_MB='8192',BYCORF_EAL_ARGS=' '.join('-a '+x['bdf'] for x in devs))
 paths=['spdk://'+x['bdf']+'/1' for x in devs[:2]]
 results={}
 for name,binary,expected in [('old',R.parent/'old-spdk-backpressure-check',1),('fixed',R.parent/'build/bycorf/bycorf_spdk_backpressure_check',0)]:
  with (R/(name+'.log')).open('w') as f:p=subprocess.run([str(binary),*paths],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  results[name]=p.returncode
  assert p.returncode==expected,(name,p.returncode)
 (R/'results.json').write_text(json.dumps(results,indent=2)+'\n')
finally:host_setup.change('restore')
