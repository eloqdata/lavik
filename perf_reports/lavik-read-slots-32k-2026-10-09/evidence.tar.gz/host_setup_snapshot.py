#!/usr/bin/env python3
import pathlib,json,os,subprocess,sys,time
R=pathlib.Path(__file__).resolve().parent
SETUP='/mnt/dev/lavik-resp-buffer-20261008/bycorf/third_party/spdk/scripts/setup.sh'
HP=pathlib.Path('/sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages')
VFIO=pathlib.Path('/sys/module/vfio/parameters/enable_unsafe_noiommu_mode')
SERIALS=['c08bc35101567ebd0005','c08bc35101567ebd0004','c08bc35101567ebd0001','c08bc35101567ebd0003','c08bc35101567ebd0002','c08bc35101567ebd0006']
def capture():
 assert not (R/'host-before.json').exists()
 devices=[]
 for i,serial in enumerate(SERIALS,1):
  ctl=pathlib.Path('/sys/class/nvme')/f'nvme{i}'
  assert (ctl/'serial').read_text().strip()==serial
  bdf=(ctl/'device').resolve().name
  namespaces=[p.name for p in pathlib.Path('/sys/class/block').glob(f'nvme{i}n*')]
  assert namespaces==[f'nvme{i}n1'],namespaces
  assert pathlib.Path('/sys/bus/pci/devices',bdf,'driver').resolve().name=='nvme'
  devices.append(dict(name=f'/dev/nvme{i}n1',serial=serial,bdf=bdf,driver='nvme'))
 out=dict(time=time.time(),devices=devices,hugepages=HP.read_text().strip(),vfio_noiommu=VFIO.read_text().strip(),iommu_groups=[p.name for p in pathlib.Path('/sys/kernel/iommu_groups').iterdir()],mounts=subprocess.check_output(['findmnt','-t','hugetlbfs'],text=True),kernel=subprocess.check_output(['uname','-a'],text=True))
 (R/'host-before.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
def active():
 assert not (R/'active-server.json').exists(),'Benchmark server still active'
 assert subprocess.run(['pgrep','-x','main-lavik'],stdout=subprocess.DEVNULL).returncode==1
 assert subprocess.run(['pgrep','-x','final-lavik'],stdout=subprocess.DEVNULL).returncode==1

def change(mode):
 assert os.geteuid()==0
 active();old=json.loads((R/'host-before.json').read_text());devs=old['devices']
 allow=' '.join(x['bdf'] for x in devs);assert len(devs)==6 and allow
 if mode=='bind':
  assert not (R/'binding-started').exists()
  for d in devs:
   n=pathlib.Path(d['name']).name
   assert pathlib.Path('/sys/block',n,'device/serial').read_text().strip()==d['serial']
   assert not list(pathlib.Path('/sys/class/block',n,'holders').iterdir())
   assert subprocess.run(['findmnt','-rn','-S',d['name']],stdout=subprocess.DEVNULL).returncode==1
   deadline=time.monotonic()+30
   while subprocess.run(['fuser',d['name']],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:
    assert time.monotonic()<deadline,d
    time.sleep(.5)
  (R/'binding-started').touch()
  subprocess.run(['modprobe','vfio-pci'],check=True)
  if not old['iommu_groups']:VFIO.write_text('1\n')
  env=dict(os.environ,PCI_ALLOWED=allow,DRIVER_OVERRIDE='vfio-pci',HUGEMEM='8192')
  subprocess.run([SETUP,'config'],env=env,check=True)
  assert int(HP.read_text())>=4096
  assert all(pathlib.Path('/sys/bus/pci/devices',d['bdf'],'driver').resolve().name=='vfio-pci' for d in devs)
  (R/'SPDK_READY').touch()
 else:
  if not (R/'binding-started').exists():return
  subprocess.run([SETUP,'reset'],env=dict(os.environ,PCI_ALLOWED=allow,DRIVER_OVERRIDE='vfio-pci'),check=True)
  HP.write_text(old['hugepages']+'\n');VFIO.write_text(('1' if old['vfio_noiommu']=='Y' else '0')+'\n')
  assert HP.read_text().strip()==old['hugepages']
  assert VFIO.read_text().strip()==old['vfio_noiommu']
  assert all(pathlib.Path('/sys/bus/pci/devices',d['bdf'],'driver').resolve().name==d['driver'] for d in devs)
  out=dict(time=time.time(),hugepages=HP.read_text().strip(),vfio_noiommu=VFIO.read_text().strip(),lsblk=subprocess.check_output(['lsblk','-o','NAME,SIZE,SERIAL,FSTYPE,MOUNTPOINTS'],text=True))
  (R/'host-restored.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':
 if sys.argv[1]=='capture':capture()
 else:change(sys.argv[1])
