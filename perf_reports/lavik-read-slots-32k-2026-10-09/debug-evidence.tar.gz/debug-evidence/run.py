#!/usr/bin/env python3
"""Diagnostic tracing at unchanged 640-connection concurrency; not a performance result."""
import pathlib,sys,json,os,resource,hashlib,time,shutil,subprocess,signal
R=pathlib.Path(__file__).resolve().parent
OLD=pathlib.Path('/mnt/dev/peer-bench/main-spdk-followup-2026-10-09')
sys.path.insert(0,str(OLD));import bench,host_setup
b=bench.b;b.R=R;b.REMOTE='/mnt/dev/spdk-saturation-debug-20261009';host_setup.R=R
BINARY=R/'lavik-debug'

def session(name,kib):
 d=R/name;assert not d.exists()
 args=json.loads((OLD/'20-main-spdk-1b/server-command.json').read_text())[3:]
 binary=BINARY
 args[0]=str(binary)
 args=[a for a in args if not a.startswith('--log-dir=') and a!='--defrag-paused']
 args+=['--log-dir='+str(d/'logs')]
 # Compare the complete candidate (including SPDK backpressure) with the
 # original runtime and 1 MiB slots, keeping all build/runtime flags fixed.
 if kib!=32:args+=['--storage-read-buffer-kb='+str(kib)]
 devs=json.loads((R/'host-before.json').read_text())['devices']
 assert all(pathlib.Path('/sys/bus/pci/devices',x['bdf'],'driver').resolve().name=='vfio-pci' for x in devs)
 env=dict(os.environ,BYCORF_DPDK_MEMORY_MB='8192',BYCORF_EAL_ARGS=' '.join('-a '+x['bdf'] for x in devs))
 resource.setrlimit(resource.RLIMIT_MEMLOCK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
 b.write(d/'environment.json',{k:env[k] for k in ['BYCORF_DPDK_MEMORY_MB','BYCORF_EAL_ARGS']})
 with b.server(args,d,env=env) as pid:
  assert b.cli('CONFIG','GET','defrag-paused').splitlines()[-1]=='no'
  b.write(d/'validation-before.json',b.validate(10**9))
  log=(d/'logs/lavik.log').read_text()
  assert f'storage_read_buffer_bytes={kib*1024} ' in log
  (d/'process-maps.txt').write_text(pathlib.Path('/proc',str(pid),'maps').read_text())
  b.memtier(d,'warmup',10**9,'GET',640,10,pid)
  tids=sorted(int(p.name) for p in pathlib.Path('/proc',str(pid),'task').iterdir())
  b.write(d/'thread-map.json',{str(t):{'name':pathlib.Path('/proc',str(pid),'task',str(t),'comm').read_text().strip(),'cpus':sorted(os.sched_getaffinity(t))} for t in tids})
  switch_filter=' || '.join(f'prev_pid == {t} || next_pid == {t}' for t in tids)
  wake_filter=' || '.join(f'pid == {t}' for t in tids)
  perfargs=['perf','record','-a','-e','sched:sched_switch','--filter',switch_filter,'-e','sched:sched_wakeup','--filter',wake_filter,'--clockid','mono','-o',str(d/'sched.data')]
  b.write(d/'perf-command.json',perfargs)
  clock=str(R.parent/'tsc-clock')
  (d/'clock-before.txt').write_text(subprocess.check_output([clock],text=True))
  with (d/'perf.log').open('w') as out:
   trace=subprocess.Popen(perfargs,stdout=out,stderr=subprocess.STDOUT)
   try:
    time.sleep(.2);assert trace.poll() is None,'perf failed to start'
    for kind in ['GET','SET']:b.memtier(d,kind.lower()+'-c640',10**9,kind,640,60 if kind=='GET' else 30,pid)
   finally:
    trace.send_signal(signal.SIGINT);trace.wait(timeout=30)
  (d/'clock-after.txt').write_text(subprocess.check_output([clock],text=True))

  b.write(d/'validation-after.json',b.validate(10**9))
 b.write(d/'complete.json',{'read_payload_kib':kib,'sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'time':time.time()})

def main():
 assert not (R/'BENCHMARKS_COMPLETE').exists()
 assert BINARY.exists()
 host_setup.capture()
 try:
  host_setup.change('bind')
  for n,kib in enumerate([32,1024],1):
   if (R/'STOP').exists():raise RuntimeError('Stop requested')
   session(f'{n:02d}-read-{kib}k',kib)
  (R/'BENCHMARKS_COMPLETE').touch()
 finally:host_setup.change('restore')
if __name__=='__main__':main()
