import pathlib,re,json,collections,bisect
p=pathlib.Path('/mnt/dev/peer-bench/spdk-saturation-debug-2026-10-09/pressure/01-read-32k')
a=[list(map(int,x.split())) for f in ['clock-before.txt','clock-after.txt'] for x in (p/f).read_text().splitlines()]; x0,y0=a[1]; x1,y1=a[-2]; slope=(y1-y0)/(x1-x0)
def ts(x):return (y0+(x-x0)*slope)/1e9
threads=json.loads((p/'thread-map.json').read_text()); tids={int(k):v['cpus'][0] for k,v in threads.items() if len(v['cpus'])==1}; tids.pop(max(tids))
last={}; off=collections.defaultdict(list); first=1e20; end=0
pat=re.compile(r'\]\s+(\d+\.\d+): sched:sched_switch: (.*):(\d+) \[\d+\] (\S+) ==> (.*):(\d+) \[\d+\]')
for l in (p/'sched.txt').open():
 m=pat.search(l)
 if not m:continue
 t=float(m[1]);first=min(first,t);end=max(end,t);prev=int(m[3]);nxt=int(m[6]);state=m[4]
 if prev in tids:last[prev]=(t,state,m[5],nxt)
 if nxt in tids and nxt in last:
  st,s,name,other=last.pop(nxt);off[tids[nxt]].append((st,t,s,name,other))
print('trace',first,end,'off counts',{k:len(v) for k,v in off.items()})
seen=set();ev=None;events=[]
for l in (p/'server.log').read_text().splitlines():
 if l.startswith('SPDK_DEBUG pressure'):
  f=dict(re.findall(r'(\w+)=([^ ]+)',l));ev={'h':f,'polls':[]};events.append(ev)
 elif l.startswith('SPDK_DEBUG poll') and ev:ev['polls'].append(dict(re.findall(r'(\w+)=([^ ]+)',l)))
for e in events:
 h=e['h'];w=int(h['worker']);t=ts(int(h['tick']))
 if w in seen:continue
 seen.add(w);print('\nFIRST',w,round(t,9),'covered',first<=t<=end)
 for q in e['polls']:
  gap=float(q['gap_us'])/1e6
  if gap<.001:continue
  stop=ts(int(q['tick']));start=stop-gap
  overlaps=[(s,f,st,n,i,max(0,min(f,stop)-max(s,start))*1e6) for s,f,st,n,i in off[w] if f>=start and s<=stop]
  print('poll',round(stop,9),'gap_us',q['gap_us'],'before',q['before'],'off_us',round(sum(v[-1] for v in overlaps),1),overlaps[:5])
print('\nTASKS')
for l in (p/'server.log').read_text().splitlines():
 if not l.startswith('TASK_DEBUG'):continue
 f=dict(re.findall(r'(\w+)=([^ ]+)',l));start=ts(int(f['tick']));end=start+float(f['elapsed_us'])/1e6;w=int(f['worker'])
 if start<first:continue
 overlaps=[(s,e,st,n,i,max(0,min(e,end)-max(s,start))*1e6) for s,e,st,n,i in off[w] if e>=start and s<=end]
 print(w,round(start,9),f['elapsed_us'],f['actor'],'off_us',round(sum(v[-1] for v in overlaps),1),overlaps[:3])
