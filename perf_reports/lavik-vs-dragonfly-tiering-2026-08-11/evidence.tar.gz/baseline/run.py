#!/usr/bin/env python3
"""Run the original 200M tiering workload on serial-allowlisted scratch media."""
import argparse, contextlib, fcntl, hashlib, json, os, pathlib, re, resource
import shlex, signal, socket, subprocess as sp, time
import common as b
P=pathlib.Path
R=b.R
KEYS=200_000_000
FILL_CONNECTIONS=640
SERIALS=json.loads((R/'protocol.json').read_text())['nvme_serials']
SETUP='/mnt/dev/lavik/bycorf/third_party/spdk/scripts/setup.sh'
MD='/dev/md/lavik-tiering-beta1'
MOUNT=P('/mnt/lavik-tiering-beta1-raid')
STAGES=['lavik-spdk','lavik-raw','lavik-files','dragonfly','garnet','kvrocks','pika','tendis','keydb']

def record_command(directory,name,args,**kw):
    b.write(directory/(name+'.command.json'),[str(x) for x in args])
    with (directory/(name+'.log')).open('a') as f:
        return b.run(args,stdout=f,stderr=sp.STDOUT,**kw)

def inventory():
    found=[]
    for ctrl in P('/sys/class/nvme').glob('nvme*'):
        serial=(ctrl/'serial').read_text().strip()
        if serial not in SERIALS:continue
        pci=(ctrl/'device').resolve()
        blocks=list(P('/sys/class/block').glob(ctrl.name+'n*'))
        assert len(blocks)==1,(ctrl,blocks)
        block=blocks[0];device='/dev/'+block.name
        assert not list(block.glob(block.name+'p*')),device
        assert not list((block/'holders').iterdir()),device
        assert sp.run(['findmnt','-rn','-S',device],stdout=sp.DEVNULL).returncode!=0,device
        assert device not in P('/proc/swaps').read_text(),device
        assert (block/'nsid').read_text().strip()=='1'
        assert (pci/'driver').resolve().name=='nvme'
        deadline=time.monotonic()+60
        while sp.run(['fuser',device],stdout=sp.DEVNULL,stderr=sp.DEVNULL).returncode==0:
            if time.monotonic()>deadline:raise RuntimeError('Device busy: '+device)
            time.sleep(.5)
        size=int((block/'size').read_text())*512
        assert size==1919850381312,(device,size)
        found.append({'serial':serial,'bdf':pci.name,'device':device,'bytes':size})
    assert sorted(x['serial'] for x in found)==sorted(SERIALS),found
    return sorted(found,key=lambda x:x['serial'])

def discard(directory,devices):
    b.event('clearing serial-verified scratch media: '+directory.name)
    # Validate the complete set before erasing any one member.
    assert inventory()==devices
    for i,d in enumerate(devices):record_command(directory,f'discard-{i}',['blkdiscard',d['device']])

def bind(directory,devices,mode):
    env=dict(os.environ,PCI_ALLOWED=' '.join(d['bdf'] for d in devices),DRIVER_OVERRIDE='vfio-pci',HUGEMEM='8192',TARGET_USER='azureuser')
    b.write(directory/('driver-'+mode+'.env.json'),{k:env[k] for k in ['PCI_ALLOWED','DRIVER_OVERRIDE','HUGEMEM','TARGET_USER']})
    record_command(directory,'driver-'+mode,[SETUP,mode],env=env)
    for d in devices:
        assert (P('/sys/bus/pci/devices')/d['bdf']/'driver').resolve().name==('vfio-pci' if mode=='config' else 'nvme')

@contextlib.contextmanager
def storage(stage,directory):
    devices=inventory();b.write(directory/'devices-before.json',devices)
    discard(directory,devices)
    mounts=[];raid_created=False;bound=False;saved=None
    env=dict(os.environ)
    try:
        if stage=='lavik-spdk':
            b.run(['modprobe','vfio-pci'])
            huge=P('/sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages')
            unsafe=P('/sys/module/vfio/parameters/enable_unsafe_noiommu_mode')
            saved={'hugepages':huge.read_text().strip(),'vfio_noiommu':unsafe.read_text().strip()}
            b.write(directory/'host-state-before.json',saved)
            unsafe.write_text('1')
            bound=True
            bind(directory,devices,'config')
            paths=['spdk://'+d['bdf']+'/1' for d in devices]
            env.update(BYCORF_EAL_ARGS=' '.join('-a '+d['bdf'] for d in devices),BYCORF_DPDK_MEMORY_MB='8192')
            b.write(directory/'eal-environment.json',{k:v for k,v in env.items() if k.startswith('BYCORF_')})
        elif stage=='lavik-raw':paths=[d['device'] for d in devices]
        elif stage=='lavik-files':
            paths=[]
            for i,d in enumerate(devices):
                mount=P(f'/mnt/lavik-tiering-beta1-disk{i}')
                mount.mkdir(exist_ok=True)
                assert not any(mount.iterdir()),mount
                record_command(directory,f'mkfs-{i}',['mkfs.xfs','-f','-K',d['device']])
                record_command(directory,f'mount-{i}',['mount','-o','noatime',d['device'],mount]);mounts.append(mount)
                path=mount/'lavik.data'
                record_command(directory,f'fallocate-{i}',['fallocate','-l','1600G',path])
                paths.append(str(path))
        else:
            assert not P(MD).exists(),MD
            MOUNT.mkdir(exist_ok=True)
            assert not any(MOUNT.iterdir()),MOUNT
            record_command(directory,'md-create',['mdadm','--create',MD,'--run','--level=0','--raid-devices='+str(len(devices)),'--metadata=1.2','--chunk=512',*[d['device'] for d in devices]])
            raid_created=True
            record_command(directory,'mkfs',['mkfs.xfs','-f','-K',MD])
            record_command(directory,'mount',['mount','-o','noatime',MD,MOUNT]);mounts.append(MOUNT)
            record_command(directory,'md-detail',['mdadm','--detail',MD])
            paths=[str(MOUNT)]
        record_command(directory,'lsblk',['lsblk','-b','-o','NAME,SIZE,MODEL,SERIAL,FSTYPE,MOUNTPOINTS'])
        yield paths,env
    finally:
        # The server context exits before storage cleanup; never rebind live I/O.
        assert not (R/'active-server.json').exists(),'Server may still own storage'
        for mount in reversed(mounts):record_command(directory,'umount-'+mount.name,['umount',mount])
        if raid_created:record_command(directory,'md-stop',['mdadm','--stop',MD])
        if bound:bind(directory,devices,'reset')
        if saved:
            huge.write_text(saved['hugepages']);unsafe.write_text('1' if saved['vfio_noiommu']=='Y' else '0')
            b.write(directory/'host-state-after.json',{'hugepages':huge.read_text().strip(),'vfio_noiommu':unsafe.read_text().strip()})
        b.write(directory/'devices-after.json',inventory())

def workload(directory,name,pid,seconds=300):
    if (R/'STOP').exists():raise RuntimeError('STOP requested')
    fill=name=='fill';remote=b.REMOTE+'/'+directory.name+'/'+name
    args=['taskset','-c','0-15','memtier_benchmark','--server='+b.S,'--port=6379','--protocol=redis',
          '--threads='+('16' if fill else '8'),'--clients='+(str(FILL_CONNECTIONS//16) if fill else '10'),'--pipeline=1',
          '--key-prefix=kv_','--key-minimum=1','--key-maximum='+str(KEYS),'--distinct-client-seed',
          '--random-data','--data-size-range=1000-4000','--data-size-pattern=R','--hide-histogram',
          '--print-percentiles=50,99,99.9,99.99','--show-config','--json-out-file='+remote+'.json']
    if fill:args+=['--requests='+str(KEYS//FILL_CONNECTIONS),'--ratio=1:0','--key-pattern=P:P']
    else:args+=['--test-time='+str(seconds),'--ratio='+{'get':'0:1','warmup':'0:1','mixed':'1:1','set':'1:0'}[name],'--randomize']
    b.write(directory/(name+'.command.json'),args)
    b.snapshot(directory/(name+'.before.json'),pid)
    b.event(directory.name+'/'+name)
    command='mkdir -p '+shlex.quote(str(P(remote).parent))+'; ulimit -n 65535; exec '+shlex.join(args)
    start=time.time()
    with (directory/(name+'.txt')).open('w') as f:
        b.ssh(command,stdout=f,stderr=sp.STDOUT,timeout=172800)
    with (directory/(name+'.json')).open('w') as f:b.ssh('cat '+shlex.quote(remote+'.json'),stdout=f)
    b.write(directory/(name+'.timing.json'),{'start':start,'end':time.time()})
    stats=json.loads((directory/(name+'.json')).read_text())['ALL STATS'];t=stats['Totals']
    assert t['Connection Errors']==0,t['Connection Errors']
    assert str(stats['Runtime']['Interrupted']).lower()=='false'
    if fill:assert t['Count']==KEYS,t['Count']
    gets=stats.get('Gets',{})
    assert gets.get('Misses/sec',0)==0,gets.get('Misses/sec')
    text=(directory/(name+'.txt')).read_text()
    assert not re.search(r'error response|connection error|error:|OOM command',text,re.I),'Client reported error'
    b.snapshot(directory/(name+'.after.json'),pid)
    server_log=(directory/'server.log').read_text(errors='replace')
    assert not re.search(r'crit:|fatal error|DllNotFoundException|ProcessMessages threw|Corruption:|Background Error',server_log,re.I),'Server reported an error; inspect server.log'
    pct=t['Percentile Latencies']
    result={'system':directory.name,'workload':name,'qps':t['Ops/sec'],'avg_ms':t['Average Latency'],'p99_ms':pct['p99.00'],'p999_ms':pct['p99.90'],'count':t['Count'],'connection_errors':t['Connection Errors'],'get_misses_per_second':gets.get('Misses/sec',0)}
    b.write(directory/(name+'.result.json'),result)
    b.event(f'{directory.name}/{name} COMPLETE: {result["qps"]:,.0f} QPS')

def check_dataset(directory,stage,when):
    # Completed client SETs are already checked in workload(). Do not issue
    # DBSIZE or a scan here: some peers implement it as an expensive operation
    # or a cached statistic. Begin the next workload directly after loading.
    fill=json.loads((directory/'fill.result.json').read_text())
    b.write(directory/('validation-'+when+'.json'),{
        'count_method':'completed partitioned sequential client load; no server key-count query',
        'completed_set_operations':fill['count']})

def peer_command(stage,directory,data,env):
    data.mkdir(exist_ok=True)
    if stage=='dragonfly':
        args=['/mnt/dev/peer-bench/dragonfly/dragonfly-v1.40.1','--logtostderr','--bind='+b.S,'--proactor_threads=16','--maxmemory=64GB','--dir='+str(data),'--dbfilename=','--tiered_prefix='+str(data/'tier'),'--tiering_disk_storage_initial_size=40GB','--backing_file_direct=false','--tiered_offload_threshold=1.0','--tiered_experimental_cooling=false','--tiered_max_pending_stash_bytes=16MB']
    elif stage=='garnet':
        cwd=R/'downloads/garnet/net10.0'
        env.update(DOTNET_ROOT='/mnt/dev/peer-bench/garnet/v2.1.5/dotnet',DOTNET_CLI_TELEMETRY_OPTOUT='1',LD_LIBRARY_PATH=str(cwd))
        args=[cwd/'GarnetServer','--bind',b.S,'--protected-mode','false','--memory','64g','--page','4m','--segment','1g','--index','4g','--index-max-size','4g','--storage-tier','--logdir',data/'log','--checkpointdir',data/'checkpoints','--readcache','--readcache-memory','32g','--readcache-page','4m','--no-obj','--no-pubsub','--device-type','Native','--device-io-backend','Libaio','--device-completion-threads','4','--device-throttle-limit','512','--initial-io-record-size','8k','--compaction-freq','300','--compaction-type','Lookup','--compaction-force-delete','--network-connection-limit','10000','--minthreads','16','--miniothreads','16','--logger-level','Warning']
    else:
        configs=json.loads((R/'peer-configs.json').read_text())
        original_data='/mnt/data/keydb-flash' if stage=='keydb' else '/mnt/data/'+stage
        config=configs[stage].replace(original_data,str(data)).replace('10.0.0.4',b.S)
        if stage=='pika':
            base=(R/'sources/pika/conf/pika.conf').read_text()
            for line in config.splitlines():
                if not line.strip():continue
                key=line.split(':',1)[0].strip()
                base,n=re.subn(r'^'+re.escape(key)+r'\s*:.*$',line,base,flags=re.M)
                if not n:base+='\n'+line+'\n'
            config=base
        conf=directory/(stage+'.conf');conf.write_text(config)
        for sub in ['db','log','dump','dbsync']:(data/sub).mkdir(exist_ok=True)
        bins={'kvrocks':R/'sources/kvrocks/build/kvrocks','pika':R/'sources/pika/output/pika','tendis':R/'downloads/tendis/tendisplus-2.8.4-rocksdb-v8.5.3/bin/tendisplus','keydb':R/'sources/keydb/src/keydb-server'}
        args=[bins[stage],*(['-c',conf] if stage in ['kvrocks','pika'] else [conf])]
    return args,env

def stage_run(stage):
    directory=R/'runs'/stage;directory.mkdir(parents=True,exist_ok=False)
    b.INFO_SECTIONS=['SERVER','MEMORY','STATS'] if stage=='garnet' else None
    with storage(stage,directory) as (paths,env):
        if stage.startswith('lavik'):
            args=[b.LAVIK,'--bind='+b.S,'--storage='+('spdk' if stage=='lavik-spdk' else 'uring'),'--tomb-raider-interval-ms=0','--log-dir='+str(directory/'logs')]+['--data-file='+p for p in paths]
            if stage=='lavik-spdk':args+=['--spdk-max-completions-per-poll=16']
        else:args,env=peer_command(stage,directory,MOUNT/stage,env)
        b.write(directory/'runtime-environment.json',{k:v for k,v in env.items() if k.startswith(('BYCORF_','DOTNET_','LD_LIBRARY_PATH'))})
        cwd=R/'downloads/garnet/net10.0' if stage=='garnet' else directory
        b.write(directory/'server-cwd.json',str(cwd))
        with b.server(args,directory,env=env,cwd=cwd) as pid:
            if stage.startswith('lavik'):assert b.cli('CONFIG','GET','defrag-paused').splitlines()==['defrag-paused','no']
            if stage=='keydb':assert 'storage_provider:flash' in b.cli('INFO','MEMORY')
            workload(directory,'fill',pid)
            check_dataset(directory,stage,'before')
            if stage=='dragonfly':workload(directory,'warmup',pid,180)
            for kind in ['get','mixed','set']:
                if stage.startswith('lavik'):
                    if kind!='get':
                        for key,value in [('MAX-ACTIVE','2' if kind=='mixed' else '6'),('BLOCK-SLEEP','15' if kind=='mixed' else '0'),('RECORD-SLEEP','0')]:
                            response=b.cli('DEFRAG',key,value)
                            assert response=='OK',(key,response)
                    (directory/(kind+'.defrag-before.txt')).write_text(b.cli('DEFRAG','STATUS')+'\n')
                workload(directory,kind,pid)
            check_dataset(directory,stage,'after')
    (directory/'COMPLETE').write_text(str(time.time())+'\n')
    b.event('COMPLETE '+stage)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('stages',nargs='*',choices=STAGES);ap.add_argument('--allow-clear-benchmark-disks',action='store_true');a=ap.parse_args()
    if not a.allow_clear_benchmark_disks:raise RuntimeError('Explicit scratch disk authorization required')
    resource.setrlimit(resource.RLIMIT_MEMLOCK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
    resource.setrlimit(resource.RLIMIT_NOFILE,(1048576,1048576))
    with (R.parent/'nightly-retest.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            with socket.create_connection((b.S,6379),timeout=1):raise RuntimeError('Port 6379 is occupied')
        except ConnectionRefusedError:pass
        b.snapshot(R/'host/before.json')
        for stage in a.stages or STAGES:
            if (R/'runs'/stage/'COMPLETE').exists():continue
            if (R/'STOP').exists():raise RuntimeError('STOP requested')
            stage_run(stage)
        b.snapshot(R/'host/after.json')
        b.event('ALL REQUESTED STAGES COMPLETE')
        (R/'ALL_COMPLETE').write_text(str(time.time())+'\n')
if __name__=='__main__':
    def stop(signum, frame):
        raise KeyboardInterrupt('Stop signal '+str(signum))
    signal.signal(signal.SIGTERM, stop)
    try:main()
    except BaseException as e:
        b.event('FAILED: '+repr(e));raise
