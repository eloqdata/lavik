#!/usr/bin/env python3
"""Compare every requested point without replacing the original observations."""
import csv,json,pathlib
R=pathlib.Path(__file__).resolve().parent
BASE=R.parent/'tiering-beta1-retest-2026-09-18'
assert (R/'ALL_COMPLETE').exists()
rows=[]
for system in ['lavik-spdk','lavik-raw','lavik-files']:
    assert (R/'runs'/system/'COMPLETE').exists()
    for kind in ['get','mixed','set']:
        old=json.loads((BASE/'runs'/system/(kind+'.result.json')).read_text())
        new=json.loads((R/'runs'/system/(kind+'.result.json')).read_text())
        assert new['connection_errors']==0 and new['get_misses_per_second']==0
        raw=json.loads((R/'runs'/system/(kind+'.json')).read_text())['ALL STATS']['Totals']
        assert raw['Ops/sec']==new['qps'] and raw['Percentile Latencies']['p99.90']==new['p999_ms']
        row={'system':system,'workload':kind,'flush_max_ms':100}
        for metric in ['qps','p99_ms','p999_ms']:
            row['baseline_'+metric]=old[metric];row['rerun_'+metric]=new[metric]
            row[metric+'_change_percent']=(new[metric]/old[metric]-1)*100
        rows.append(row)
with (R/'comparison.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
text=['# Lavik partial-block flush deadline: 100 ms rerun','',
      'Same official beta release, six drives, fresh 200M-key load per backend, 80 connections and 300 seconds per workload. The partial-block flush deadline is 100 ms throughout loading and all windows, versus 1000 ms in the baseline. All defrag settings remain unchanged. Baseline and rerun evidence are retained separately. The rerun additionally samples INFO/DEFRAG every five seconds.',
      '', '| Backend | Workload | Original QPS | 100 ms QPS | QPS change | Original p99.9 ms | 100 ms p99.9 ms |',
      '|---|---|---:|---:|---:|---:|---:|']
for d in rows:
    text.append(f"| {d['system']} | {d['workload']} | {d['baseline_qps']:,.2f} | {d['rerun_qps']:,.2f} | {d['qps_change_percent']:+.2f}% | {d['baseline_p999_ms']:.3f} | {d['rerun_p999_ms']:.3f} |")
text+=['','Per-second throughput remains in each memtier JSON. Timestamped reclamation samples are in `runs/<backend>/<workload>.reclamation.jsonl`. An active defrag permit can include its cooldown, so this gauge alone does not measure CPU or disk utilization.','']
(R/'comparison.md').write_text('\n'.join(text))
print('\n'.join(text))
