import argparse, contextlib, hashlib, json, os, pathlib, re, resource, shlex
import signal, socket, subprocess as sp, sys, time, urllib.request
R = pathlib.Path(__file__).resolve().parent
S = '172.16.0.4'; CLIENT = 'azureuser@172.16.0.5'; PORT = 6379
REMOTE = '/mnt/dev/lavik-tiering-beta1-flush100-20260919'
CLI = '/mnt/dev/peer-bench/redis/v8.8.0/src/src/redis-cli'
LAVIK = R/'downloads/lavik-v0.1.0-beta.1-linux-x86_64/lavik'
DEVICES = [f'/dev/nvme{i}n1' for i in range(1,7)]
SERIALS = {1: '40291d45b421bc880006', 2: '40291d45b421bc880002', 3: '40291d45b421bc880005', 4: '40291d45b421bc880001', 5: '40291d45b421bc880004', 6: '40291d45b421bc880003'}
CONNECTIONS = [80,160,320,640,1280]
INFO_SECTIONS = None
DBSIZE_TIMEOUT = 120
resource.setrlimit(resource.RLIMIT_NOFILE,(65535,65535))

def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj,indent=2)+'\n')
def event(message):
    print(time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),message,flush=True)
    write(R/'status.json',{'time':time.time(),'message':message,'pid':os.getpid()})
def run(args, **kw):
    return sp.run([str(x) for x in args],check=True,**kw)
def out(args, **kw):
    return sp.check_output([str(x) for x in args],text=True,**kw).strip()
def ssh(command, **kw):
    return run(['sudo','-u','azureuser','ssh','-o','BatchMode=yes',CLIENT,command],**kw)
def cli(*args):
    if args==('INFO','ALL') and INFO_SECTIONS:
        return '\n'.join(cli('INFO',section) for section in INFO_SECTIONS)
    timeout=DBSIZE_TIMEOUT if args and args[0]=='DBSIZE' else 120
    return out([CLI,'-h',S,'-p',PORT,'--raw',*args],timeout=timeout)
def snapshot(path, pid=None):
    d={'time':time.time(),'clock_ticks':os.sysconf('SC_CLK_TCK')}
    for f in ['stat','meminfo','diskstats','interrupts','net/dev','net/softnet_stat','softirqs']:
        d[f]=pathlib.Path('/proc/'+f).read_text()
    d['irq_affinity']={str(p):p.read_text().strip() for p in pathlib.Path('/proc/irq').glob('*/smp_affinity_list')}
    if pid:
        for f in ['stat','status','io']:
            with contextlib.suppress(FileNotFoundError): d['process_'+f]=pathlib.Path(f'/proc/{pid}/{f}').read_text()
        d['threads']={t.name:sorted(os.sched_getaffinity(int(t.name))) for t in pathlib.Path(f'/proc/{pid}/task').iterdir()}
        d['info']=cli('INFO','ALL')
    write(path,d)
@contextlib.contextmanager
def server(args, directory, env=None, cwd=None):
    directory.mkdir(parents=True,exist_ok=True)
    try:
        with socket.create_connection((S,PORT),timeout=1):raise RuntimeError('Benchmark port already occupied')
    except ConnectionRefusedError:pass
    args=['taskset','-c','0-15',*[str(x) for x in args]]
    write(directory/'server-command.json',args)
    event('starting '+str(args[3]))
    with (directory/'server.log').open('a') as f:
        p=sp.Popen(args,stdout=f,stderr=sp.STDOUT,env=env,cwd=cwd)
    write(R/'active-server.json',{'pid':p.pid,'command':args,'directory':str(directory)})
    try:
        deadline=time.monotonic()+600
        while time.monotonic()<deadline:
            if p.poll() is not None:raise RuntimeError('Server exited: '+str(directory))
            try:
                if cli('PING')=='PONG':break
            except sp.SubprocessError:pass
            time.sleep(.5)
        else:raise TimeoutError('Server startup')
        yield p.pid
    finally:
        requested_stop = p.poll() is None
        if requested_stop:
            p.send_signal(signal.SIGTERM)
            try:p.wait(timeout=300)
            except sp.TimeoutExpired:
                p.kill();p.wait();raise RuntimeError('Server did not shut down cleanly')
        (directory/'exit-code.txt').write_text(str(p.returncode)+'\n')
        (R/'active-server.json').unlink(missing_ok=True)
        expected_garnet_stop = requested_stop and pathlib.Path(args[3]).name == 'GarnetServer' and p.returncode == -signal.SIGTERM
        if p.returncode != 0 and not expected_garnet_stop:raise RuntimeError('Server exit code '+str(p.returncode))

