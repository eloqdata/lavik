#!/usr/bin/env python3
"""Run the isolated matrix with lightweight reclamation samples."""
import json,signal,threading,time
import common as b
import run as bench
original=bench.workload
def monitored(directory,name,pid,seconds=300):
    stop=threading.Event()
    failures=[]
    def collect():
        with (directory/(name+'.reclamation.jsonl')).open('w') as f:
            while not stop.is_set():
                row={'time':time.time(),'workload':name}
                try:
                    row['defrag_status']=b.cli('DEFRAG','STATUS')
                    row['info']=b.cli('INFO','ALL')
                except Exception as e:
                    row['error']=repr(e);failures.append(repr(e))
                row['sample_finished']=time.time()
                f.write(json.dumps(row)+'\n');f.flush()
                stop.wait(5)
    thread=threading.Thread(target=collect)
    thread.start()
    try:original(directory,name,pid,seconds)
    finally:
        stop.set();thread.join()
    assert not failures,failures
bench.workload=monitored
def terminate(signum,frame):raise KeyboardInterrupt('Stop signal '+str(signum))
signal.signal(signal.SIGTERM,terminate)
try:bench.main()
except BaseException as e:
    b.event('FAILED: '+repr(e));raise
